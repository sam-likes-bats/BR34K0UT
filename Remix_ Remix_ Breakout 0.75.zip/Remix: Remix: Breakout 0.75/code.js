var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["cf568940-0c21-405a-a980-32833bdf2347","04168a74-0db2-44ca-9002-be26a2e3515d","67a4d0b9-5b37-4d8c-aac8-313c7a54aad3"],"propsByKey":{"cf568940-0c21-405a-a980-32833bdf2347":{"name":"ball1","sourceUrl":null,"frameSize":{"x":35,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"JYJmwEkCrD6W8LfcLuuhgtYPFf.RotcE","loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":30},"rootRelativePath":"assets/cf568940-0c21-405a-a980-32833bdf2347.png"},"04168a74-0db2-44ca-9002-be26a2e3515d":{"name":"ball2","sourceUrl":null,"frameSize":{"x":35,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"46T_CqmjnXnnHlBvtwYr5qgEUG475Tlz","loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":30},"rootRelativePath":"assets/04168a74-0db2-44ca-9002-be26a2e3515d.png"},"67a4d0b9-5b37-4d8c-aac8-313c7a54aad3":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"FElrHuZqVyOdoA5dJ2LmzGKRm6ULppfB","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/67a4d0b9-5b37-4d8c-aac8-313c7a54aad3.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//made by sam!
var GameState="nothing";
var yes=yes;
var no=no;


var box1 = createSprite(25, 75, 50, 50);
box1.shapeColor="red";
var box2 = createSprite(75, 75, 50, 50);
box2.shapeColor="blue";
var box3 = createSprite(125, 75, 50, 50);
box3.shapeColor="red";
var box4 = createSprite(175, 75, 50, 50);
box4.shapeColor="blue";
var box5 = createSprite(225, 75, 50, 50);
box5.shapeColor="red";
var box6 = createSprite(275, 75, 50, 50);
box6.shapeColor="blue";
var box7 = createSprite(325, 75, 50, 50);
box7.shapeColor="red";
var box8 = createSprite(375, 75, 50, 50);
box8.shapeColor="blue";


var box9 = createSprite(25, 125, 50, 50);
box9.shapeColor="blue";
var box10 = createSprite(75, 125, 50, 50);
box10.shapeColor="red";
var box11 = createSprite(125, 125, 50, 50);
box11.shapeColor="blue";
var box12 = createSprite(175, 125, 50, 50);
box12.shapeColor="red";
var box13 = createSprite(225,125, 50, 50);
box13.shapeColor="blue";
var box14 = createSprite(275, 125, 50, 50);
box14.shapeColor="red";
var box15 = createSprite(325, 125, 50, 50);
box15.shapeColor="blue";
var box16 = createSprite(375, 125, 50, 50);
box16.shapeColor="red";

var paddle=createSprite(200,390,100,20);
var ball=createSprite(200,200,20,20);
ball.setAnimation("ball1");
createEdgeSprites();
var points = 0;

function draw() {
  ball.bounceOff(paddle);
  ball.bounceOff(topEdge);
  ball.bounceOff(leftEdge);
  ball.bounceOff(rightEdge);
  ball.bounceOff(paddle);
   background("white");
  if (GameState=="nothing"){
    fill(rgb(196, 75, 103));
    textSize(20);
    text("welcome! press SPACE to start", 56, 179);
    if (keyDown("space")){
    ball.velocityY = 7;
    ball.velocityX = 5;
    fill(rgb(255, 255, 255));
    text("welcome! press SPACE to start", 56, 179);
    GameState ="playing";
    
     } 
    
  }
 if (GameState=="playing"){
  paddle.x = World.mouseX;
 }
if (ball.y >403){
   background("white");
  fill(rgb(196, 75, 103));
  textSize(40);
  text(">GAME OVER<", 90, 200);
  textSize(20);
  text("try again?", 160, 220);

 GameState="end";
  
}
  drawSprites();
 if (GameState=="end"){
   ball.setVelocity(0,0);
   
 }
 if (keyDown("r")){
   ball.x =200;
   ball.y=200;
   GameState="nothing";
   if (GameState=="nothing"){
    fill(rgb(196, 75, 103));
    textSize(20);
    text("welcome! press SPACE to start", 56, 179);
    if (keyDown("space")){
    ball.velocityY = 7;
    ball.velocityX = 5;
    fill(rgb(255, 255, 255));
    text("welcome! press SPACE to start", 56, 179);
    GameState ="playing";}
    
 }}
  
  if(ball.isTouching(box1)){
    box1.destroy();
    points=points+1;

    }
    if(ball.isTouching(box2)){
    box2.destroy();
    points=points+1;
    }
    if(ball.isTouching(box3)){
    box3.destroy();
    points=points+1;
    }
    if(ball.isTouching(box4)){
    box4.destroy();
    points=points+1;
    }
    if(ball.isTouching(box5)){
    box5.destroy();
    points=points+1;
    }
    if(ball.isTouching(box6)){
    box6.destroy();
    points=points+1;
    }
    if(ball.isTouching(box7)){
    box7.destroy();
    points=points+1;
    }
    if(ball.isTouching(box8)){
    box8.destroy();
    points=points+1;
    }
    if(ball.isTouching(box9)){
    box9.destroy();
    points=points+1;
    }
    if(ball.isTouching(box10)){
    box10.destroy();
    points=points+1;
    }
    if(ball.isTouching(box11)){
    box11.destroy();
    points=points+1;
    }
    if(ball.isTouching(box12)){
    box12.destroy();
    points=points+1;
    }
    if(ball.isTouching(box13)){
    box13.destroy();
    points=points+1;
    }
    if(ball.isTouching(box14)){
    box14.destroy();
    points=points+1;
    }
    if(ball.isTouching(box15)){
    box15.destroy();
    points=points+1;
    }
    if(ball.isTouching(box16)){
      
      box16.destroy();
    points=points+1;
    }
    
   if (ball.isTouching(paddle)) {
     ball.setAnimation("ball2");
   }
    fill(rgb(121, 61, 61));
    textSize(20);
    text("points: "+points, 20, 20);
    
    if (points == 16){
     background("white");
     fill(rgb(121, 61, 61))
     textSize(40);
     text("YOU WON", 120, 200);
     ball.bounceOff(edges);
    }
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
